import pytest
from pages.login_page import LoginPage
from pages.secure_page import SecurePage
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


# 1️⃣ NEGATİF LOGIN — parametrize
@pytest.mark.parametrize(
    "username,password,expected",
    [
        ("tomsmith", "WRONG_PASSWORD", "Your password is invalid!"),
        ("wronguser", "SuperSecretPassword!", "Your username is invalid!"),
    ]
)
def test_invalid_login(driver, username, password, expected):
    login = LoginPage(driver)

    login.open()
    login.login(username, password)

    assert expected in login.get_message()


# 2️⃣ POZİTİF LOGIN + PROTECTED PAGE
def test_successful_login_and_access_secure_page(driver):
    login = LoginPage(driver)

    login.open()
    login.login("tomsmith", "SuperSecretPassword!")

    secure = SecurePage(driver)
    assert "Secure Area" in secure.header_text()


# 3️⃣ LOGOUT
def test_logout(driver):
    login = LoginPage(driver)

    login.open()
    login.login("tomsmith", "SuperSecretPassword!")

    secure = SecurePage(driver)
    secure.logout()

    wait = WebDriverWait(driver, 10)
    flash = wait.until(
        EC.presence_of_element_located((By.ID, "flash"))
    )

    assert "You logged out of the secure area!" in flash.text


# 4️⃣ FAIL CASE — LOGIN OLMADAN PROTECTED PAGE (DOĞRU DOĞRULAMA)
def test_access_secure_page_without_login(driver):
    driver.get("https://the-internet.herokuapp.com/secure")

    wait = WebDriverWait(driver, 10)
    flash = wait.until(
        EC.presence_of_element_located((By.ID, "flash"))
    )

    assert "You must login to view the secure area!" in flash.text
