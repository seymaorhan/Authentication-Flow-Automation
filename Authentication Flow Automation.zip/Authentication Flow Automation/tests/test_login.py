import pytest
from pages.login_page import LoginPage

@pytest.mark.parametrize(
    "username,password,expected_text",
    [
        ("tomsmith", "WRONG_PASSWORD", "Your password is invalid!"),
        ("wronguser", "SuperSecretPassword!", "Your username is invalid!"),
        ("", "", "Your username is invalid!")
    ]
)
def test_login_scenarios(driver, username, password, expected_text):
    login_page = LoginPage(driver)

    login_page.open()
    login_page.login(username, password)

    message = login_page.get_message()
    assert expected_text in message
